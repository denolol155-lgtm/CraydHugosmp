package de.crayd.mod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class CraydHomeScreen extends Screen {
    public CraydHomeScreen() {
        super(Text.literal("Crayd Mod"));
    }

    @Override
    protected void init() {
        int cardWidth = 260;
        int x = width / 2 - cardWidth / 2;
        int y = height / 2 - 25;
        addDrawableChild(ButtonWidget.builder(Text.literal("Drop Tweaks  ›"), button ->
                client.setScreen(new DropTweaksScreen(this)))
                .dimensions(x, y, cardWidth, 42).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(0, 0, width, height, 0xB80A0D18);
        context.drawCenteredTextWithShadow(textRenderer, "CRAYD", width / 2, height / 2 - 88, 0x55F2D8);
        context.drawCenteredTextWithShadow(textRenderer, "MOD 1", width / 2, height / 2 - 68, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "Minecraft 1.21.11", width / 2, height / 2 - 50, 0xAEB8C8);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

package de.crayd.mod.mixin;

import de.crayd.mod.CraydModClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.Registries;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "dropSelectedItem", at = @At("HEAD"), cancellable = true)
    private void crayd$blockSelectedDrop(boolean entireStack, CallbackInfoReturnable<Boolean> cir) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        String itemId = Registries.ITEM.getId(player.getMainHandStack().getItem()).toString();
        if (CraydModClient.CONFIG.isProtected(itemId)) {
            cir.setReturnValue(false);
        }
    }
}

package de.crayd.mod.mixin;

import de.crayd.mod.CraydModClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(method = "dropCreativeStack", at = @At("HEAD"), cancellable = true)
    private void crayd$blockCreativeDrop(ItemStack stack, CallbackInfo ci) {
        String id = Registries.ITEM.getId(stack.getItem()).toString();
        if (CraydModClient.CONFIG.isProtected(id)) ci.cancel();
    }

    @Inject(method = "clickSlot", at = @At("HEAD"), cancellable = true)
    private void crayd$blockInventoryThrow(int syncId, int slotId, int button,
                                           SlotActionType actionType, PlayerEntity player,
                                           CallbackInfo ci) {
        if (actionType == SlotActionType.THROW && slotId >= 0
                && slotId < player.currentScreenHandler.slots.size()) {
            String id = Registries.ITEM.getId(player.currentScreenHandler.getSlot(slotId).getStack().getItem()).toString();
            if (CraydModClient.CONFIG.isProtected(id)) ci.cancel();
        }
    }
}

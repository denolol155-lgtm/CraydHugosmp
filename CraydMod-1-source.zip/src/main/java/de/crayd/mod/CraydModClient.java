package de.crayd.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class CraydModClient implements ClientModInitializer {
    public static final DropConfig CONFIG = new DropConfig();
    private static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        CONFIG.load();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.craydmod.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new CraydHomeScreen());
                }
            }
        });
    }
}

package de.crayd.mod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

public final class DropConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("crayd-drop-tweaks.json");
    private final Set<String> protectedItems = new HashSet<>();
    public boolean isProtected(String id) { return protectedItems.contains(id); }
    public Set<String> all() { return Set.copyOf(protectedItems); }
    public void toggle(String id) {
        if (!protectedItems.add(id)) protectedItems.remove(id);
        save();
    }
    public void load() {
        if (!Files.exists(FILE)) return;
        try (Reader r = Files.newBufferedReader(FILE)) {
            Data d = GSON.fromJson(r, Data.class);
            if (d != null && d.items != null) protectedItems.addAll(d.items);
        } catch (Exception ignored) { }
    }
    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer w = Files.newBufferedWriter(FILE)) { GSON.toJson(new Data(protectedItems), w); }
        } catch (Exception ignored) { }
    }
    private record Data(Set<String> items) {}
}

package de.crayd.mod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.List;
import java.util.Locale;

public final class DropTweaksScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget search;
    private List<Item> visible = List.of();
    private int scroll;
    private static final int CELL = 34;
    private static final int COLS = 9;

    public DropTweaksScreen(Screen parent) {
        super(Text.literal("Drop Tweaks"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        search = new TextFieldWidget(textRenderer, width / 2 - 150, 45, 300, 22, Text.literal("Item suchen"));
        search.setPlaceholder(Text.literal("Item suchen..."));
        search.setChangedListener(text -> rebuild());
        addDrawableChild(search);
        addDrawableChild(ButtonWidget.builder(Text.literal("Zurück"), button -> client.setScreen(parent))
                .dimensions(width / 2 - 70, height - 30, 140, 20).build());
        rebuild();
    }

    private void rebuild() {
        String query = search == null ? "" : search.getText().toLowerCase(Locale.ROOT);
        visible = Registries.ITEM.stream().filter(item -> {
            Identifier id = Registries.ITEM.getId(item);
            return query.isBlank()
                    || id.toString().contains(query)
                    || item.getName().getString().toLowerCase(Locale.ROOT).contains(query);
        }).toList();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, visible.size() - 1)));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(0, 0, width, height, 0xD90B1020);
        context.drawCenteredTextWithShadow(textRenderer, "CRAYD  /  DROP TWEAKS", width / 2, 14, 0x55F2D8);
        context.drawCenteredTextWithShadow(textRenderer,
                "Item anklicken = Dropschutz an/aus", width / 2, 29, 0xD7DEEA);
        super.render(context, mouseX, mouseY, delta);

        int left = width / 2 - (COLS * CELL) / 2;
        int top = 82;
        int rows = Math.max(1, (height - top - 42) / CELL);
        for (int n = 0; n < COLS * rows; n++) {
            int index = scroll + n;
            if (index >= visible.size()) break;
            int x = left + (n % COLS) * CELL;
            int y = top + (n / COLS) * CELL;
            Item item = visible.get(index);
            String id = Registries.ITEM.getId(item).toString();
            boolean protectedItem = CraydModClient.CONFIG.isProtected(id);
            context.fill(x, y, x + 30, y + 30, protectedItem ? 0xE018806F : 0xAA30394B);
            context.drawItem(new ItemStack(item), x + 7, y + 7);
            if (protectedItem) context.drawText(textRenderer, "✓", x + 20, y + 1, 0xFFFFFF, true);
            if (mouseX >= x && mouseX < x + 30 && mouseY >= y && mouseY < y + 30) {
                context.drawTooltip(textRenderer,
                        Text.literal(item.getName().getString() + "  •  " + (protectedItem ? "AN" : "AUS")),
                        mouseX, mouseY);
            }
        }
        context.drawText(textRenderer,
                "Geschützt: " + CraydModClient.CONFIG.all().size() + "  |  Mausrad zum Scrollen",
                left, height - 42, 0xE5EAF2, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int left = width / 2 - (COLS * CELL) / 2;
        int top = 82;
        int rows = Math.max(1, (height - top - 42) / CELL);
        if (button == 0 && mouseX >= left && mouseX < left + COLS * CELL
                && mouseY >= top && mouseY < top + rows * CELL) {
            int column = (int) (mouseX - left) / CELL;
            int row = (int) (mouseY - top) / CELL;
            int index = scroll + row * COLS + column;
            if (index >= 0 && index < visible.size()) {
                CraydModClient.CONFIG.toggle(Registries.ITEM.getId(visible.get(index)).toString());
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int rows = Math.max(1, (height - 124) / CELL);
        int max = Math.max(0, visible.size() - COLS * rows);
        scroll = Math.max(0, Math.min(max, scroll - (int) (verticalAmount * COLS)));
        return true;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

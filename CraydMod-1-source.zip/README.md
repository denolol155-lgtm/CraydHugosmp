# Crayd Mod 1 — Minecraft Java 1.21.11

Eine Client-Mod für Fabric. Die Mod enthält nur **Drop Tweaks**; es gibt keine ESP-Module, keine Discord-Schaltfläche, kein Info-Menü und kein Zahnrad.

## Bedienung
- `Rechte Umschalttaste` öffnet das Crayd-Menü.
- Im Menü gibt es nur **Drop Tweaks**.
- In Drop Tweaks kannst du Minecraft-Items über das Suchfeld suchen.
- Jedes Item wird als Minecraft-Icon angezeigt. Anklicken schaltet den Dropschutz für dieses Item ein oder aus.
- Geschützte Items werden beim Drücken von Q, beim Werfen aus dem Inventar und beim Creative-Drop blockiert.
- Die Auswahl wird in `config/crayd-drop-tweaks.json` gespeichert.

## Projekt bauen
Benötigt Java 21 und Gradle. Im Projektordner ausführen:

```bash
gradle build
```

Die Mod-JAR wird bei erfolgreichem Build unter `build/libs/` erstellt.

## Technischer Status
Dieses ZIP enthält den vollständigen Quellcode und das Crayd-Logo. In der aktuellen Arbeitsumgebung sind weder Gradle noch ein Internetzugang zum Herunterladen der Minecraft-/Fabric-Abhängigkeiten verfügbar. Deshalb konnte ich hier **keinen Gradle-Build und keinen Starttest in Minecraft** durchführen. Die Datei ist ein Quellprojekt, keine bereits getestete JAR.
